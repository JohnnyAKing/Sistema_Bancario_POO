
public class Cliente
{
    private String cpf;
    private String nome;
   
    public String getNome(){
        return nome;
    }
    
    public String getCPF(){
        return cpf;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public void setCPF(String cpf){
        this.cpf = cpf;
    }
    
}
